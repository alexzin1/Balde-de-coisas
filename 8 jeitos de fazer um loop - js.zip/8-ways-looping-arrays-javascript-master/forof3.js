const canal = "Código Fonte TV"

for (let letra of canal) {
    console.log(letra)
}