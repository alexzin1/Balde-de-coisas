const bolsaVanessa = [
    'cartão de crédito',
    'chaves',
    'dinheiro',
    'escova de cabelo',
    'lenço de papel',
    'perfume',
    'alcool gel'
]

bolsaVanessa.forEach((value, index) => {
    console.log(`${index+1}. ${value}`)
})