export const SAVE_COMMENT = 'save comment';
export const FETCH_COMMENTS = 'fetch_comments'
export const CHANGE_AUTH = 'change_auth'
