# Change Log

### 1.0.1 - 9/3/2018

- Fix issues and implement suggestions from Udacity code review (see issues #53, #54, #55, #56)

### 1.0.0 - 9/2/2018

- Initial release